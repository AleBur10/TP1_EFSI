
var button = document.getElementById("prom");
var button2 = document.getElementById("notaMasAlta");



button.onclick = function() {
    var notaMate = document.getElementById("notaMate").value;
    var notaLengua = document.getElementById("notaLengua").value;
    var notaEfsi = document.getElementById("notaEfsi").value;

    var textoPromedio = document.getElementById("promedio");
    textoPromedio.innerHTML ="";
    if (notaMate == 0 || notaLengua == 0 || notaEfsi == 0) {
        alert("No esta cargado un valor")
    } else {
        notaMate = parseInt(notaMate);
        notaLengua = parseInt(notaLengua);
        notaEfsi = parseInt(notaEfsi);

        var promedio = (notaMate + notaLengua + notaEfsi)/3;
        textoPromedio.innerHTML = "El promedio es " + promedio;
        
        if (promedio >= 6) {
            textoPromedio.style.color = "green";
        } else {
            textoPromedio.style.color = "red";
        }
    }

}


button2.onclick = function() {
    var notaMate = parseInt(document.getElementById("notaMate").value);
    var notaLengua = parseInt(document.getElementById("notaLengua").value);
    var notaEfsi = parseInt(document.getElementById("notaEfsi").value);
    var notaMayor = "";

    var textoNotaMayor = document.getElementById("notaMayor");
    textoNotaMayor.innerHTML ="";

    if (notaMate >= notaLengua && notaMate >= notaEfsi) {
        notaMayor = "Matematica";
    }
    else if (notaLengua >= notaMate && notaLengua >= notaEfsi) {
        notaMayor = "Lengua";
    }
    else {
        notaMayor = "EFSI";
    }
    if (notaMate == notaLengua == notaEfsi) {
        notaMayor = "Matematica, Lengua y EFSI";
    }else if (notaMate == notaLengua) {
        notaMayor = "Matematica y Lengua";
    }else if (notaMate == notaEfsi) {
        notaMayor = "Matematica y EFSI";
    }else if (notaLengua == notaEfsi) {
        notaMayor = "Lengua y EFSI";
    }
    textoNotaMayor.style.color = "blue";
    textoNotaMayor.innerHTML = "La nota mas alta es la de " + notaMayor;    
}

